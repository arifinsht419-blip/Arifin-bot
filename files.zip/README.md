# 🤖 IDX Stock AI Agent — Telegram Bot

Analisa teknikal real-time saham Indonesia (IDX) via Telegram.

---

## 📦 CARA SETUP (Step by Step)

### 1. Install Python
Pastikan Python 3.10+ sudah terinstall:
```
python --version
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Buat Telegram Bot
1. Buka Telegram, cari **@BotFather**
2. Ketik `/newbot`
3. Beri nama bot, contoh: `IDX Stock Analyzer`
4. Beri username, contoh: `idx_saham_bot`
5. Copy **TOKEN** yang diberikan BotFather

### 4. Set Token
Edit file `bot.py`, ganti baris ini:
```python
TELEGRAM_TOKEN = "MASUKKAN_TOKEN_BOT_DISINI"
```
Dengan token dari BotFather:
```python
TELEGRAM_TOKEN = "1234567890:ABCdefGhIjKlMnOpQrStUvWxYz"
```

Atau set via environment variable (lebih aman):
```bash
export TELEGRAM_TOKEN="token_lo_disini"
```

### 5. Jalankan Bot
```bash
python bot.py
```

Bot aktif! Buka Telegram dan mulai chat dengan bot lo.

---

## 💬 CARA PAKAI BOT

| Command | Fungsi |
|---|---|
| `BBCA` | Analisa lengkap saham BBCA |
| `/analisa TLKM` | Analisa saham TLKM |
| `/harga GOTO` | Cek harga cepat |
| `/top` | Daftar saham IDX populer |
| `/help` | Bantuan |

---

## 📊 INDIKATOR YANG DIGUNAKAN

| Indikator | Fungsi |
|---|---|
| MA5 / MA20 / MA50 | Trend direction |
| RSI (14) | Overbought / Oversold |
| MACD | Momentum |
| Bollinger Bands | Volatilitas & support/resistance |
| Volume | Konfirmasi sinyal |

### Sistem Skoring:
- Score ≥ +3 → **BELI**
- Score ≤ -3 → **JUAL**
- Antara -3 dan +3 → **HOLD**

---

## ☁️ DEPLOY KE SERVER (Optional - agar bot jalan 24/7)

### Opsi A: VPS (Digital Ocean / Vultr / Contabo)
```bash
# Install screen atau tmux
apt install screen
screen -S idxbot
python bot.py
# Ctrl+A+D untuk detach
```

### Opsi B: Railway.app (Gratis)
1. Push kode ke GitHub
2. Connect repo ke Railway.app
3. Set environment variable TELEGRAM_TOKEN
4. Deploy!

### Opsi C: Render.com (Gratis)
1. Buat akun di render.com
2. New → Background Worker
3. Set build command: `pip install -r requirements.txt`
4. Set start command: `python bot.py`
5. Add environment variable TELEGRAM_TOKEN

---

## ⚠️ DISCLAIMER

Bot ini menggunakan analisa teknikal sebagai **alat bantu** saja.
- Data dari Yahoo Finance (delay ~15 menit)
- BUKAN saran investasi resmi
- Selalu lakukan riset sendiri (DYOR)
- Pasar saham mengandung risiko
