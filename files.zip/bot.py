"""
IDX Stock AI Agent - Telegram Bot
Analisa teknikal real-time saham Indonesia (IDX)
"""

import os
import logging
import asyncio
from datetime import datetime, timedelta
import yfinance as yf
import pandas as pd
import numpy as np
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, MessageHandler,
    CallbackQueryHandler, ContextTypes, filters
)

# ─── CONFIG ──────────────────────────────────────────────────────────────────
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN", "MASUKKAN_TOKEN_BOT_DISINI")
ALLOWED_USERS   = []  # kosongkan = semua user bisa akses, isi dengan user_id untuk restrict

logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(message)s",
    level=logging.INFO
)
log = logging.getLogger(__name__)

# ─── HELPER: fetch IDX stock data ────────────────────────────────────────────
def get_stock(ticker: str) -> yf.Ticker:
    """Tambahkan .JK jika belum ada (IDX suffix)"""
    if not ticker.upper().endswith(".JK"):
        ticker = ticker.upper() + ".JK"
    return yf.Ticker(ticker)

def fetch_ohlcv(ticker: str, period: str = "3mo", interval: str = "1d") -> pd.DataFrame:
    stock = get_stock(ticker)
    df = stock.history(period=period, interval=interval)
    if df.empty:
        raise ValueError(f"Ticker {ticker} tidak ditemukan atau tidak ada data.")
    return df

# ─── TECHNICAL INDICATORS ────────────────────────────────────────────────────
def add_indicators(df: pd.DataFrame) -> pd.DataFrame:
    close = df["Close"]

    # Moving Averages
    df["MA5"]  = close.rolling(5).mean()
    df["MA20"] = close.rolling(20).mean()
    df["MA50"] = close.rolling(50).mean()

    # RSI (14)
    delta = close.diff()
    gain  = delta.clip(lower=0).rolling(14).mean()
    loss  = (-delta.clip(upper=0)).rolling(14).mean()
    rs    = gain / loss.replace(0, np.nan)
    df["RSI"] = 100 - (100 / (1 + rs))

    # MACD
    ema12 = close.ewm(span=12, adjust=False).mean()
    ema26 = close.ewm(span=26, adjust=False).mean()
    df["MACD"]        = ema12 - ema26
    df["MACD_signal"] = df["MACD"].ewm(span=9, adjust=False).mean()
    df["MACD_hist"]   = df["MACD"] - df["MACD_signal"]

    # Bollinger Bands
    sma20 = close.rolling(20).mean()
    std20 = close.rolling(20).std()
    df["BB_upper"] = sma20 + 2 * std20
    df["BB_lower"] = sma20 - 2 * std20
    df["BB_mid"]   = sma20

    # Volume MA
    df["VOL_MA20"] = df["Volume"].rolling(20).mean()

    return df

# ─── SIGNAL ENGINE ────────────────────────────────────────────────────────────
def generate_signal(df: pd.DataFrame) -> dict:
    row  = df.iloc[-1]
    prev = df.iloc[-2]

    signals = []
    score   = 0  # positif = bullish, negatif = bearish

    # 1. MA Cross (Golden/Death cross)
    if row["MA5"] > row["MA20"] and prev["MA5"] <= prev["MA20"]:
        signals.append("📈 Golden Cross MA5/MA20 — sinyal BELI kuat")
        score += 2
    elif row["MA5"] < row["MA20"] and prev["MA5"] >= prev["MA20"]:
        signals.append("📉 Death Cross MA5/MA20 — sinyal JUAL kuat")
        score -= 2

    # 2. Harga vs MA50
    if row["Close"] > row["MA50"]:
        signals.append("✅ Harga di atas MA50 — trend bullish")
        score += 1
    else:
        signals.append("⚠️ Harga di bawah MA50 — trend bearish")
        score -= 1

    # 3. RSI
    rsi = row["RSI"]
    if rsi < 30:
        signals.append(f"🟢 RSI {rsi:.1f} — oversold, potensi rebound BELI")
        score += 2
    elif rsi > 70:
        signals.append(f"🔴 RSI {rsi:.1f} — overbought, potensi koreksi JUAL")
        score -= 2
    else:
        signals.append(f"🟡 RSI {rsi:.1f} — netral")

    # 4. MACD
    if row["MACD"] > row["MACD_signal"] and prev["MACD"] <= prev["MACD_signal"]:
        signals.append("📈 MACD crossover — momentum BELI")
        score += 2
    elif row["MACD"] < row["MACD_signal"] and prev["MACD"] >= prev["MACD_signal"]:
        signals.append("📉 MACD crossunder — momentum JUAL")
        score -= 2
    elif row["MACD_hist"] > 0:
        signals.append("🟢 MACD histogram positif — bullish")
        score += 1
    else:
        signals.append("🔴 MACD histogram negatif — bearish")
        score -= 1

    # 5. Bollinger Bands
    if row["Close"] < row["BB_lower"]:
        signals.append("💡 Harga menyentuh BB bawah — potensi bounce BELI")
        score += 1
    elif row["Close"] > row["BB_upper"]:
        signals.append("⚡ Harga menyentuh BB atas — potensi reversal JUAL")
        score -= 1

    # 6. Volume
    if row["Volume"] > row["VOL_MA20"] * 1.5:
        vol_note = "🔊 Volume tinggi (konfirmasi sinyal kuat)"
        score = score * 1.3 if score > 0 else score * 1.3
    else:
        vol_note = "🔇 Volume normal"
    signals.append(vol_note)

    # Final decision
    if score >= 3:
        decision = "🟢 BELI (BUY)"
        strength = "Kuat" if score >= 5 else "Moderat"
    elif score <= -3:
        decision = "🔴 JUAL (SELL)"
        strength = "Kuat" if score <= -5 else "Moderat"
    else:
        decision = "🟡 HOLD / WAIT"
        strength = "Sinyal lemah — tunggu konfirmasi"

    return {
        "decision": decision,
        "strength": strength,
        "score": score,
        "signals": signals,
        "rsi": rsi,
        "macd": row["MACD"],
        "macd_signal": row["MACD_signal"],
        "close": row["Close"],
        "ma5": row["MA5"],
        "ma20": row["MA20"],
        "ma50": row["MA50"],
        "bb_upper": row["BB_upper"],
        "bb_lower": row["BB_lower"],
        "volume": row["Volume"],
        "vol_ma20": row["VOL_MA20"],
    }

# ─── FORMAT MESSAGE ───────────────────────────────────────────────────────────
def format_analysis(ticker: str, df: pd.DataFrame, sig: dict) -> str:
    ticker_display = ticker.upper().replace(".JK", "") + " (IDX)"
    now = datetime.now().strftime("%d %b %Y %H:%M WIB")

    chg     = df["Close"].iloc[-1] - df["Close"].iloc[-2]
    chg_pct = (chg / df["Close"].iloc[-2]) * 100
    arrow   = "▲" if chg >= 0 else "▼"

    msg = f"""
╔══════════════════════════════╗
  📊 *ANALISA SAHAM IDX*
  🏷 *{ticker_display}*
  🕐 {now}
╚══════════════════════════════╝

💰 *Harga Terakhir:* Rp {sig['close']:,.0f}
{arrow} *Perubahan:* {chg:+,.0f} ({chg_pct:+.2f}%)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📐 *INDIKATOR TEKNIKAL*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• MA5   : Rp {sig['ma5']:,.0f}
• MA20  : Rp {sig['ma20']:,.0f}
• MA50  : Rp {sig['ma50']:,.0f}
• RSI   : {sig['rsi']:.1f}
• MACD  : {sig['macd']:.4f}
• Signal: {sig['macd_signal']:.4f}
• BB ↑  : Rp {sig['bb_upper']:,.0f}
• BB ↓  : Rp {sig['bb_lower']:,.0f}
• Volume: {sig['volume']:,.0f}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔍 *SINYAL YANG TERDETEKSI*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""
    for s in sig["signals"]:
        msg += f"• {s}\n"

    msg += f"""
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎯 *KEPUTUSAN: {sig['decision']}*
💪 *Kekuatan: {sig['strength']}*
📊 Score: {sig['score']:.1f}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚠️ _Ini bukan saran investasi. Selalu DYOR._
"""
    return msg.strip()

# ─── TELEGRAM HANDLERS ───────────────────────────────────────────────────────
async def start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    kb = [
        [InlineKeyboardButton("📊 Analisa Saham", callback_data="help_analisa")],
        [InlineKeyboardButton("📋 Top IDX", callback_data="top_idx")],
        [InlineKeyboardButton("❓ Cara Pakai", callback_data="help_cara")],
    ]
    await update.message.reply_text(
        "🤖 *IDX Stock AI Agent*\n\n"
        "Bot analisa saham Indonesia real-time.\n\n"
        "Ketik ticker saham, contoh:\n"
        "`BBCA` `TLKM` `GOTO` `ASII`\n\n"
        "Atau ketik `/analisa BBCA`",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup(kb)
    )

async def help_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "📖 *Cara Pakai IDX Bot*\n\n"
        "1️⃣ Kirim kode saham IDX langsung:\n"
        "   `BBCA` atau `BBCA.JK`\n\n"
        "2️⃣ Gunakan command:\n"
        "   `/analisa TLKM` — analisa teknikal\n"
        "   `/harga GOTO` — cek harga cepat\n"
        "   `/top` — daftar saham populer IDX\n\n"
        "3️⃣ Contoh saham IDX populer:\n"
        "   BBCA, BBRI, TLKM, ASII, GOTO,\n"
        "   BMRI, UNVR, ICBP, HMSP, PGAS\n\n"
        "⚠️ _Data dari Yahoo Finance (delay ~15 menit)_",
        parse_mode="Markdown"
    )

async def analisa_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not ctx.args:
        await update.message.reply_text("❌ Contoh: `/analisa BBCA`", parse_mode="Markdown")
        return
    ticker = ctx.args[0].strip()
    await run_analysis(update, ticker)

async def harga_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not ctx.args:
        await update.message.reply_text("❌ Contoh: `/harga TLKM`", parse_mode="Markdown")
        return
    ticker = ctx.args[0].strip().upper()
    try:
        stock = get_stock(ticker)
        info  = stock.fast_info
        price = info.last_price
        await update.message.reply_text(
            f"💰 *{ticker} (IDX)*\n"
            f"Harga: Rp {price:,.0f}",
            parse_mode="Markdown"
        )
    except Exception as e:
        await update.message.reply_text(f"❌ Error: {e}")

async def top_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    top = [
        ("BBCA","Bank Central Asia"), ("BBRI","Bank Rakyat Indonesia"),
        ("TLKM","Telkom Indonesia"), ("ASII","Astra International"),
        ("BMRI","Bank Mandiri"), ("GOTO","GoTo Gojek Tokopedia"),
        ("UNVR","Unilever Indonesia"), ("ICBP","Indofood CBP"),
        ("PGAS","Perusahaan Gas Negara"), ("ADRO","Adaro Energy"),
    ]
    kb = [[InlineKeyboardButton(f"{t} — {n}", callback_data=f"analyze_{t}")] for t, n in top]
    await update.message.reply_text(
        "📋 *Saham IDX Populer*\nPilih untuk analisa:",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup(kb)
    )

async def handle_text(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip().upper()
    # Jika input terlihat seperti ticker (2-6 huruf)
    if text.isalpha() and 2 <= len(text) <= 6:
        await run_analysis(update, text)
    else:
        await update.message.reply_text(
            "💬 Ketik kode saham IDX, contoh: `BBCA` `TLKM` `GOTO`\n"
            "Atau `/help` untuk bantuan.",
            parse_mode="Markdown"
        )

async def handle_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data

    if data.startswith("analyze_"):
        ticker = data.replace("analyze_", "")
        await run_analysis(query, ticker)
    elif data == "top_idx":
        await top_cmd(query, ctx)
    elif data == "help_cara":
        await query.message.reply_text(
            "📖 Kirim kode saham IDX langsung, contoh: `BBCA`",
            parse_mode="Markdown"
        )

async def run_analysis(update_or_query, ticker: str):
    """Jalankan analisa dan kirim hasilnya."""
    is_callback = hasattr(update_or_query, "message") and not hasattr(update_or_query, "reply_text")

    async def reply(text, **kwargs):
        if hasattr(update_or_query, "message"):
            await update_or_query.message.reply_text(text, **kwargs)
        else:
            await update_or_query.reply_text(text, **kwargs)

    await reply(f"🔄 Menganalisa *{ticker.upper()}* ...", parse_mode="Markdown")

    try:
        df  = fetch_ohlcv(ticker)
        df  = add_indicators(df)
        sig = generate_signal(df)
        msg = format_analysis(ticker, df, sig)
        await reply(msg, parse_mode="Markdown")
    except ValueError as e:
        await reply(f"❌ {e}\nPastikan kode saham benar (contoh: BBCA, TLKM)")
    except Exception as e:
        log.error(f"Error analisa {ticker}: {e}")
        await reply(f"❌ Gagal mengambil data. Coba lagi nanti.\n`{e}`", parse_mode="Markdown")

# ─── MAIN ─────────────────────────────────────────────────────────────────────
def main():
    app = Application.builder().token(TELEGRAM_TOKEN).build()

    app.add_handler(CommandHandler("start",   start))
    app.add_handler(CommandHandler("help",    help_cmd))
    app.add_handler(CommandHandler("analisa", analisa_cmd))
    app.add_handler(CommandHandler("harga",   harga_cmd))
    app.add_handler(CommandHandler("top",     top_cmd))
    app.add_handler(CallbackQueryHandler(handle_callback))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))

    log.info("🤖 IDX Stock Bot started...")
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
