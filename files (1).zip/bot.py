"""
Arifin Stock Analyzer - IDX AI Agent
Deploy-ready for Railway.app
"""

import os
import logging
from datetime import datetime
import yfinance as yf
import pandas as pd
import numpy as np
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, MessageHandler,
    CallbackQueryHandler, ContextTypes, filters
)

TELEGRAM_TOKEN = os.environ["TELEGRAM_TOKEN"]

logging.basicConfig(format="%(asctime)s | %(levelname)s | %(message)s", level=logging.INFO)
log = logging.getLogger(__name__)

def fetch_ohlcv(ticker: str) -> pd.DataFrame:
    t = ticker.upper()
    if not t.endswith(".JK"):
        t += ".JK"
    df = yf.Ticker(t).history(period="3mo", interval="1d")
    if df.empty:
        raise ValueError(f"Saham *{ticker.upper()}* tidak ditemukan di IDX.")
    return df

def add_indicators(df: pd.DataFrame) -> pd.DataFrame:
    c = df["Close"]
    df["MA5"]      = c.rolling(5).mean()
    df["MA20"]     = c.rolling(20).mean()
    df["MA50"]     = c.rolling(50).mean()
    delta          = c.diff()
    gain           = delta.clip(lower=0).rolling(14).mean()
    loss           = (-delta.clip(upper=0)).rolling(14).mean()
    df["RSI"]      = 100 - (100 / (1 + gain / loss.replace(0, np.nan)))
    ema12          = c.ewm(span=12, adjust=False).mean()
    ema26          = c.ewm(span=26, adjust=False).mean()
    df["MACD"]     = ema12 - ema26
    df["MACD_sig"] = df["MACD"].ewm(span=9, adjust=False).mean()
    sma20          = c.rolling(20).mean()
    std20          = c.rolling(20).std()
    df["BB_up"]    = sma20 + 2 * std20
    df["BB_dn"]    = sma20 - 2 * std20
    df["VOL_MA20"] = df["Volume"].rolling(20).mean()
    return df

def generate_signal(df: pd.DataFrame) -> dict:
    r, p   = df.iloc[-1], df.iloc[-2]
    score  = 0
    events = []

    if r.MA5 > r.MA20 and p.MA5 <= p.MA20:
        events.append("📈 Golden Cross MA5/MA20 — sinyal BELI kuat"); score += 2
    elif r.MA5 < r.MA20 and p.MA5 >= p.MA20:
        events.append("📉 Death Cross MA5/MA20 — sinyal JUAL kuat"); score -= 2

    if r.Close > r.MA50:
        events.append("✅ Harga di atas MA50 — trend bullish"); score += 1
    else:
        events.append("⚠️ Harga di bawah MA50 — trend bearish"); score -= 1

    if r.RSI < 30:
        events.append(f"🟢 RSI {r.RSI:.1f} — oversold, potensi BELI"); score += 2
    elif r.RSI > 70:
        events.append(f"🔴 RSI {r.RSI:.1f} — overbought, potensi JUAL"); score -= 2
    else:
        events.append(f"🟡 RSI {r.RSI:.1f} — netral")

    if r.MACD > r.MACD_sig and p.MACD <= p.MACD_sig:
        events.append("📈 MACD crossover — momentum BELI"); score += 2
    elif r.MACD < r.MACD_sig and p.MACD >= p.MACD_sig:
        events.append("📉 MACD crossunder — momentum JUAL"); score -= 2
    elif r.MACD - r.MACD_sig > 0:
        events.append("🟢 MACD histogram positif"); score += 1
    else:
        events.append("🔴 MACD histogram negatif"); score -= 1

    if r.Close < r.BB_dn:
        events.append("💡 Menyentuh Bollinger bawah — potensi bounce BELI"); score += 1
    elif r.Close > r.BB_up:
        events.append("⚡ Menyentuh Bollinger atas — potensi reversal JUAL"); score -= 1

    high_vol = r.Volume > r.VOL_MA20 * 1.5
    events.append("🔊 Volume tinggi — sinyal terkonfirmasi" if high_vol else "🔇 Volume normal")
    if high_vol: score = int(score * 1.3)

    if score >= 3:
        dec, str_ = "🟢 BELI (BUY)", ("Kuat 💪" if score >= 5 else "Moderat")
    elif score <= -3:
        dec, str_ = "🔴 JUAL (SELL)", ("Kuat 💪" if score <= -5 else "Moderat")
    else:
        dec, str_ = "🟡 HOLD / TUNGGU", "Sinyal lemah — tunggu konfirmasi"

    return dict(decision=dec, strength=str_, score=score, events=events,
                close=r.Close, ma5=r.MA5, ma20=r.MA20, ma50=r.MA50,
                rsi=r.RSI, macd=r.MACD, macd_sig=r.MACD_sig,
                bb_up=r.BB_up, bb_dn=r.BB_dn, volume=r.Volume, vol_ma20=r.VOL_MA20)

def build_msg(ticker: str, df: pd.DataFrame, s: dict) -> str:
    chg   = df.Close.iloc[-1] - df.Close.iloc[-2]
    pct   = chg / df.Close.iloc[-2] * 100
    arrow = "▲" if chg >= 0 else "▼"
    now   = datetime.now().strftime("%d %b %Y %H:%M")
    sigs  = "\n".join(f"  • {e}" for e in s["events"])
    return f"""🤖 *ARIFIN STOCK ANALYZER*
📊 *{ticker.upper()} — IDX*
🕐 {now} WIB

💰 Harga : *Rp {s['close']:,.0f}*
{arrow} Perubahan : *{chg:+,.0f} ({pct:+.2f}%)*

━━━━━━━━━━━━━━━━━━━━
📐 *INDIKATOR*
  MA5   → Rp {s['ma5']:,.0f}
  MA20  → Rp {s['ma20']:,.0f}
  MA50  → Rp {s['ma50']:,.0f}
  RSI   → {s['rsi']:.1f}
  MACD  → {s['macd']:.4f} / {s['macd_sig']:.4f}
  BB ↑  → Rp {s['bb_up']:,.0f}
  BB ↓  → Rp {s['bb_dn']:,.0f}

━━━━━━━━━━━━━━━━━━━━
🔍 *SINYAL TERDETEKSI*
{sigs}

━━━━━━━━━━━━━━━━━━━━
🎯 *KEPUTUSAN : {s['decision']}*
💪 Kekuatan  : {s['strength']}
📊 Score     : {s['score']}
━━━━━━━━━━━━━━━━━━━━
⚠️ _Bukan saran investasi. DYOR._""".strip()

TOP_IDX = [
    ("BBCA","Bank Central Asia"), ("BBRI","Bank Rakyat Indonesia"),
    ("TLKM","Telkom Indonesia"), ("ASII","Astra International"),
    ("BMRI","Bank Mandiri"), ("GOTO","GoTo Gojek Tokopedia"),
    ("UNVR","Unilever Indonesia"), ("ICBP","Indofood CBP"),
    ("PGAS","Perusahaan Gas Negara"), ("ADRO","Adaro Energy"),
    ("ANTM","Aneka Tambang"), ("INDF","Indofood Sukses Makmur"),
    ("HMSP","HM Sampoerna"), ("KLBF","Kalbe Farma"), ("EXCL","XL Axiata"),
]

async def do_analysis(send_fn, ticker: str):
    await send_fn(f"🔄 Menganalisa *{ticker.upper()}* ...", parse_mode="Markdown")
    try:
        df  = fetch_ohlcv(ticker)
        df  = add_indicators(df)
        s   = generate_signal(df)
        msg = build_msg(ticker, df, s)
        kb  = [[InlineKeyboardButton("🔁 Refresh", callback_data=f"refresh_{ticker.upper()}"),
                InlineKeyboardButton("📋 Top IDX", callback_data="top")]]
        await send_fn(msg, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(kb))
    except ValueError as e:
        await send_fn(f"❌ {e}", parse_mode="Markdown")
    except Exception as e:
        log.error(e)
        await send_fn("❌ Gagal ambil data. Coba lagi nanti.", parse_mode="Markdown")

async def cmd_start(update: Update, _):
    kb = [[InlineKeyboardButton("📋 Top Saham IDX", callback_data="top")],
          [InlineKeyboardButton("❓ Cara Pakai", callback_data="help")]]
    await update.message.reply_text(
        "👋 Halo! Aku *Arifin Stock Analyzer* 🤖\n\n"
        "Bot analisa saham IDX real-time.\n\n"
        "Ketik kode saham langsung:\n"
        "`BBCA`  `TLKM`  `GOTO`  `BBRI`\n\n"
        "Atau gunakan /analisa BBCA",
        parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(kb))

async def cmd_analisa(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not ctx.args:
        await update.message.reply_text("❌ Contoh: `/analisa BBCA`", parse_mode="Markdown"); return
    await do_analysis(update.message.reply_text, ctx.args[0])

async def cmd_top(update: Update, _):
    kb = [[InlineKeyboardButton(f"{t} — {n}", callback_data=f"analyze_{t}")] for t, n in TOP_IDX]
    await update.message.reply_text("📋 *Top Saham IDX*\nPilih untuk analisa:",
        parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(kb))

async def cmd_help(update: Update, _):
    await update.message.reply_text(
        "📖 *Cara Pakai Arifin Bot*\n\n"
        "1️⃣ Ketik kode saham langsung: `BBCA` `TLKM`\n"
        "2️⃣ `/analisa BBCA` — analisa teknikal\n"
        "3️⃣ `/top` — daftar saham populer IDX\n\n"
        "Indikator: MA · RSI · MACD · Bollinger · Volume\n\n"
        "⚠️ _Data Yahoo Finance, delay ~15 menit_",
        parse_mode="Markdown")

async def on_text(update: Update, _):
    t = update.message.text.strip().upper()
    clean = t.replace(".JK","")
    if clean.isalpha() and 2 <= len(clean) <= 6:
        await do_analysis(update.message.reply_text, t)
    else:
        await update.message.reply_text("Ketik kode saham IDX, contoh: `BBCA`\nAtau /help", parse_mode="Markdown")

async def on_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    d = q.data
    if d.startswith("analyze_") or d.startswith("refresh_"):
        await do_analysis(q.message.reply_text, d.split("_",1)[1])
    elif d == "top":   await cmd_top(q, ctx)
    elif d == "help":  await cmd_help(q, ctx)

def main():
    app = Application.builder().token(TELEGRAM_TOKEN).build()
    app.add_handler(CommandHandler("start",   cmd_start))
    app.add_handler(CommandHandler("analisa", cmd_analisa))
    app.add_handler(CommandHandler("top",     cmd_top))
    app.add_handler(CommandHandler("help",    cmd_help))
    app.add_handler(CallbackQueryHandler(on_callback))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, on_text))
    log.info("Arifin Stock Analyzer — AKTIF")
    app.run_polling()

if __name__ == "__main__":
    main()
